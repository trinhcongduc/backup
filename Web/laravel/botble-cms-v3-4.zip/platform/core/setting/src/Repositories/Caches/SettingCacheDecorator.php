<?php

namespace Botble\Setting\Repositories\Caches;

use Botble\Setting\Repositories\Interfaces\SettingInterface;
use Botble\Support\Repositories\Caches\CacheAbstractDecorator;

class SettingCacheDecorator extends CacheAbstractDecorator implements SettingInterface
{

}
