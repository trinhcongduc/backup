<?php

return [
    [
        'name' => 'Dashboard',
        'flag' => 'dashboard.index',
    ],
];