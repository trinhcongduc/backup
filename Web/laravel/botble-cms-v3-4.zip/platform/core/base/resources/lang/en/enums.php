<?php

return [
    'statuses' => [
        'draft'       => 'Draft',
        'pending'     => 'Pending',
        'publish'     => 'Publish',
        'activated'   => 'activated',
        'deactivated' => 'deactivated',
    ],
];