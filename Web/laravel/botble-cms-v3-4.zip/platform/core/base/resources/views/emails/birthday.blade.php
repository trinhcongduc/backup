<p>Hi {{ $user->getFullName() }},</p>
<p>My dear friend, you are not old this morning. The passing of time only makes you more beautiful and more wise, making me be proud of being your friend.</p>
<p>Happy Birthday!</p>