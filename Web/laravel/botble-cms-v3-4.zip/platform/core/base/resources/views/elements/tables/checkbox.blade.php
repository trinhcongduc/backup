<div class="text-left">
    <div class="checkbox checkbox-primary table-checkbox">
        <input type="checkbox" class="checkboxes" name="id[]" value="{{ $id }}"/>
    </div>
</div>