Folder must exists
