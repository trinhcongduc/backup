## 2. Create droplet

1. Click **Create droplet**
 - Choose an image: `Ubuntu 19.04.4 x64`
 - Choose a size: `2 GB (RAM), 1 vCPU, 50 GB (SSD)`
 - Choose a datacenter region: `San Francisco`
2. Then SSH to droplet.
