## 4. Run MongoDB
```shell
sudo service mongod start
```