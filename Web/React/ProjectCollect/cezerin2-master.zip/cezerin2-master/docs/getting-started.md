- Installation Guides

  - [Prerequisites](prerequisites.md)
  - [Using source code](using-source-code.md)
  - [Using docker](using-docker.md)

- Help
  - [Cezerin Community Site](https://cezerin.org)
  - [Slack Channel](https://cezerin2.slack.com)
  - [Slack Channel Invite](https://join.slack.com/t/cezerin2/shared_invite/enQtNTE5NzYxMzA5ODc5LTVkZjM4ODUwMmNlMmMyZTkxYjg5N2QxZmQ5NjA1NTg3OWM2ZjU1NzVmNWM0N2E3ZmJjM2Q3MjQ5OGFmNTBmYjg)
