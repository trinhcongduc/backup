package com.javacodegeeks.patterns.abstractfactorypattern;

public interface XMLParser {
	
	public String parse();

}
