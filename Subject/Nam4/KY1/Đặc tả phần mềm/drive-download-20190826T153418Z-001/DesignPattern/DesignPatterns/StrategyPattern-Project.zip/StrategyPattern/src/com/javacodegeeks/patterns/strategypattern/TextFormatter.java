package com.javacodegeeks.patterns.strategypattern;

public interface TextFormatter {
	
	public void format(String text);

}
