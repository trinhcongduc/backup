package com.javacodegeeks.patterns.flyweightpattern;

public interface Platform {

	public void execute(Code code);
}
