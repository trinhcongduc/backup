package com.javacodegeeks.patterns.decoratorpattern;

public interface Pizza {

	public String getDesc();
	public double getPrice();
}
