package com.javacodegeeks.patterns.mediatorpattern;

public interface Colleague {
	
	public void setMediator(MachineMediator mediator);

}
