package com.javacodegeeks.patterns.proxypattern.virtualproxy;

import java.util.List;

public interface ContactList {

	public List<Employee> getEmployeeList();
}
