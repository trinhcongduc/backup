package com.javacodegeeks.patterns.proxypattern.remoteproxy;

public interface ReportGenerator {
	
	public String generateDailyReport();

}
