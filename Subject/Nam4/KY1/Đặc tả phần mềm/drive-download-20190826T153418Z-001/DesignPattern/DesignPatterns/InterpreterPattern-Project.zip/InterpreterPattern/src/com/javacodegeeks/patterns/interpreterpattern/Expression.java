package com.javacodegeeks.patterns.interpreterpattern;

public interface Expression {
	public int interpret();
}
