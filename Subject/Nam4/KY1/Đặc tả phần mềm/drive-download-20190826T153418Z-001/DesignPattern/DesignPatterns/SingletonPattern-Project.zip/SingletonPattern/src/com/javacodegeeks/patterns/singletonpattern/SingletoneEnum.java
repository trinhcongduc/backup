package com.javacodegeeks.patterns.singletonpattern;

public class SingletoneEnum {

	public enum SingleEnum{
		SINGLETON_ENUM;
	}
}
